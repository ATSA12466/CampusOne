import 'package:flutter/material.dart';

import 'src/app/app_shell.dart';
import 'src/core/theme/app_theme.dart';
import 'src/core/theme/theme_prefs.dart';
import 'src/demo/demo_gate.dart';
import 'src/demo/demo_store.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CampusOneDemoApp());
}

/// A presentation build with no API client, account service, or push setup.
class CampusOneDemoApp extends StatefulWidget {
  const CampusOneDemoApp({super.key});

  @override
  State<CampusOneDemoApp> createState() => _CampusOneDemoAppState();
}

class _CampusOneDemoAppState extends State<CampusOneDemoApp> {
  final _store = DemoStore();
  late final Future<ThemePrefs> _themePrefs = ThemePrefs.load();

  @override
  void dispose() {
    _store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<ThemePrefs>(
        future: _themePrefs,
        builder: (context, snapshot) {
          final prefs = snapshot.data;
          if (prefs == null) {
            return MaterialApp(
              title: 'CampusOne · GCTU',
              theme: buildLightTheme(),
              darkTheme: buildDarkTheme(),
              home: const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              ),
            );
          }

          return AnimatedBuilder(
            animation: prefs,
            builder: (context, _) => MaterialApp(
              title: 'CampusOne · GCTU',
              debugShowCheckedModeBanner: false,
              theme: buildLightTheme(),
              darkTheme: buildDarkTheme(),
              themeMode: prefs.mode,
              // Keep appearance preferences inside the app's inherited tree so
              // auth, dialogs and navigator routes share a stable lifecycle.
              builder: (context, child) => ThemeScope(
                prefs: prefs,
                child: child ?? const SizedBox.shrink(),
              ),
              home: DemoGate(
                store: _store,
                appBuilder: (onLogout) =>
                    AppShell(store: _store, onLogout: onLogout),
              ),
            ),
          );
        },
      );
}
