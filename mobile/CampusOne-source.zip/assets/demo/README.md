Demo photography

The bundled student photos are sourced from the official Ghana Communication Technology University photo gallery, 35th Matriculation Ceremony:
https://site.gctu.edu.gh/news/gctu-inducts-over-5000-fresh-students-for-2025-2026-academic-year.aspx
https://site.gctu.edu.gh/photo-gallery?category=35th_matriculation_ceremony

Images are bundled in the app so the presentation screens work offline.

The study-library image `study-library-pexels.jpg` is by Yan Krukau, sourced from Pexels:
https://www.pexels.com/photo/students-studying-inside-the-library-8199659/

It is used as a general study illustration and does not represent a GCTU location.

Sign-in provider marks used by the auth UI are downloaded from the official
Google Identity and GitHub image endpoints. Their respective brand marks are
displayed as assets; provider authentication is not currently connected.

Google: https://developers.google.com/identity/images/g-logo.png
GitHub: https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png
